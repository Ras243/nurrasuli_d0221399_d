## Soal Tugas IV

TUGAS PERTEMUAN IV
A. Tugas Mandiri
1. Buat dan Publish SEBUAH Video Tutorial Youtube Live Coding Array yang berisi Tutorial Pembuatan Aplikasi POS (Point Of Sale)/Aplikasi Mesin Kasir dengan ketentuan Sebagai Berikut:
    a. Aplikasi dibuat berbasis CLI/Command Window menggunakan bahasa pemrograman Java
	b. Terdapat pemanfaatan minimal salah satu dari stuktur data: Array, Vector, ArrayList, LinkedList
	c. Terdapat pemanfaatan minimal salah satu dari stuktur data: Array, Vector, ArrayList, LinkedList yang bertipe class/object
	d. Program akan terus menerus membaca input (never end loop) sampai kita memasukkan kata "EXIT"
	e. Data Barang akan disimpan ke dalam file (semacam database sederhana bertipe file text)
	f. Data Barang berisi field: ID, Nama Barang, Stock, Terjual, Jenis, dan boleh ditambahkan beberapa field lainnya yang mungkin akan dibutuhkan
	g. Di Aplikasi CLI ada menu untuk menambah Barang baru dan ada menu untuk menambah jumlah stock barang untuk barang yang sudah ada
	h. Di Aplikasi CLI ada menu untuk "SAVE" Data Barang
	i. Di Aplikasi CLI ada menu "TRANSAKSI" yang akan mencatan penjualan ke konsumen dan dibagian akhir transaksi detail barang dan jumlah yang harus dibayar oleh konsumen ditampilkan ke layar
	j. Proses Transaksi akan mengakibatkan perubahan jumlah stock dan jumlah barang yang terjual.
	k. Di Aplikasi CLI ada menu untuk menampilkan Data Barang
	l. Jadi minimal ada dua View Tabel yang dapat dihasilkan: 1) View Tabel Transaksi/penjualan yang berisi detail harga, jumlah dan total pembayaran yang harus dibayar oleh konsumen. 2) View Tabel Data Barang
	m. Pada saat dijalankan Program akan membaca data barang dari file dan Program akan otomatis menyimpan Data saat menu EXIT dipilih kemudian setelah itu kita keluar dari Loop (Never End Loop)
	o. Kreatifitas dan Kerapian tampilan Program akan mendapat poin tambahan.
	p. Tampilan Menu Utama minimal seperti ini (boleh dikreasikan):
	
	============================================
	[T] TAMBAH DATA BARANG
	[R] REMOVE DATA BARANG
	[V] VIEW DATA BARANG
	[P] PENJUALAN
	[S] SAVE
	[E] EXIT
	============================================
	
	q. Tampilan submenu TAMBAH DATA BARANG
	============================================
	[TB] TAMBAH BARANG
	[TSB] TAMBAH STOK BARANG
	============================================
	
	r. Tampilan submenu PENJUALAN
	============================================
	[TP] TAMBAH PENJUALAN
	[SL] SELESAI
	============================================
	
	s. Pada saat sub menu TAMBAH PENJUALAN dipilih maka akan tampil pilihan data barang dari tabel barang yang stocknya > 0 untuk dipilih. kemudian setelah memilih barang kita diminta untuk memasukkan jumlah barang yang akan dijual. Program akan otomatis mendeteksi (memvalidasi) jika user memasukkan jumlah barang yang akan dibeli melebihi stock yang ada, program juga mampu mendeteksi/memvalidasi jika user memasukkan ID barang yang salah/tidak ada di data Barang.
	
	t. pada saat submenu [SL] SELESAI dipilih, maka program akan menampilkan detail barang, jumlah barang, harga, dan total harga yang akan dibeli oleh konsumen (semacam struk belanja), Kemudian ada menu untuk "LANJUTKAN KE PEMBAYARAN" untuk melanjutkan ke proses pembayaran oleh konsumen. Setelah barang berhasil dibayar maka (secara virtual barang diberikan ke Konsumen) kita mendapatkan tambahan saldo kas dan jumlah stock barang yang ada di Tabel data Barang berkurang dan penjualannya bertambah sesuai dengan Transaksi yang telah terjadi.
	
	u. Hanya satu File yang dibuat untuk menyimpan data barang. File ini akan diload saat pertama aplikasi dijalankan dan akan menyimpan data terbaru/terakhir sebelum aplikasi diakhiri, data dari file ini akan kembali dipanggil saat aplikasi kembali dijalankan, sehingga aktifitas dan kondisi data senantiasa sesuai dan berkelanjutan. Format file yang digunakan akan diberi penilaian khusus dengan catatan code untuk membaca file harus menggunakan library standar (JDK) bukan librari/API dari pihak ketiga. (level penilaian format file dari yang terendah ke yang tertinggi: .txt, .csv, .json) 
	
	v. Programmer harus mengantisipasi error logika, runtime error, mempersiapkan validasi input oleh user, mengantisipasi user yang sengaja maupun tidak sengaja memasukkan input/data yang tidak valid.
	
	w. hanya satu video youtube yang dibuat, berisi cara membuat dan demo penggunaan aplikasinya
	

2. Subscriber Youtube minimal 100 Subscriber tanggal 15 Maret 2022

B. Tugas Kelompok
--- belum ada tugas kelompok


>>>>SELAMAT BERJUANG<<<<
>>>>>TERIMA KASIH<<<<<<<