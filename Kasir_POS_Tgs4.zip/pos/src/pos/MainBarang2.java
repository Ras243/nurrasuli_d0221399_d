package pos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;

public class MainBarang2 {
    public static void main(String[] args) {
        int id = -1;
        ArrayList<Barang> tabelBarang = new ArrayList<>();
        ArrayList<Barang> tabelBarangDariFile = readTableBarangFromFile("file_tabel_barang.txt");
        if (tabelBarangDariFile != null) {
            tabelBarang = tabelBarangDariFile;
        }
        
        String transaksi = "C:\\Users\\Rasul\\Belajar Java\\pos\\tabelTransaksi.txt";
        Scanner sc = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\n============================================");
            System.out.println("=              ==>HALAL MART<==            =");
            System.out.println("============================================");
            System.out.println("PILIH MENU : ");
            System.out.println("[T]  TAMBAH DATA BARANG");
            System.out.println("[R]  REMOVE DATA BARANG");
            System.out.println("[V]  VIEW DATA BARANG");
            System.out.println("[P]  PENJUALAN");
            System.out.println("[S]  SAVE DATA BARANG");
            System.out.println("[E]  EXIT");
            System.out.println("============================================");
            System.out.print("Menu yang anda pilih : ");
            String input =sc.nextLine();

            if (input.equalsIgnoreCase("T")) { //kurung pembuka tambah barang
                Boolean run = true;
                while(run){
                    System.out.println("\nAnda Memilih Menu Tambah Barang");
                    System.out.println("============================================");
                    System.out.println("[TB] TAMBAH BARANG");
                    System.out.println("[TSB] TAMBAH STOK BARANG");
                    System.out.println("[SL] SELESAI");
                    System.out.println("============================================");
                    System.out.print("Input Jenis Tambah barang : ");
                    String chooise = sc.nextLine();
                    if (chooise.equalsIgnoreCase("TB")) {
                        id++;
                        System.out.print("Input Nama Barang  :");
                        String nama = sc.nextLine();

                        System.out.print("Input Harga Barang :Rp ");
                        String strHarga = sc.nextLine();
                        double harga = Double.parseDouble(strHarga);

                        System.out.print("Input Stock Barang :");
                        String strStock = sc.nextLine();
                        int stock = Integer.parseInt(strStock);
                        
                        System.out.print("Input Jenis Barang :");
                        String jenis = sc.nextLine();

                        Barang barang = new Barang(id, nama, harga, stock, jenis); //membuat object
                        tabelBarang.add(barang); // Menambahkan barang kedalam Arraylist tabelBarang
                    }
                    else if (chooise.equalsIgnoreCase("TSB")) {
                        int index = -1;
                        boolean ditemukan = false;
                        System.out.println("Anda memilih Menu TAMBAH STOCK BARANG");
                        System.out.print("Tambah Stock dengan Id :");
                        int tambah= sc.nextInt();
                        System.out.print("Jumlah penambahan stock : ");
                        int update = sc.nextInt();
                        for (int j = 0; j < tabelBarang.size(); j++) {
                            if (tabelBarang.get(j).id == id) {
                                index = j;
                                ditemukan = true;
                            }
                        }
                        if (ditemukan == true) {
                            Barang updateStock = tabelBarang.get(tambah);
                            updateStock.stock = tabelBarang.get(tambah).stock+update;
    
                        }else{
                            System.out.println("ID tidak ditemukan");
                        }
    
                    }else if (chooise.equalsIgnoreCase("SL")) {
                        System.out.println("Selesai");
                        run = false;
                    }else{
                        System.out.println("Silahkan Pilih Menu dengan Benar!");
                    }
                }

            }//kurung penutup tambah barang
            else if (input.equalsIgnoreCase("R")) {//kurung pembuka remove barang
                int index = -1;
                boolean ditemukan = false;
                System.out.println("Anda Memilih Menu REMOVE BARANG");
                System.out.println("======================================================================================");
                System.out.println("|                                 Tampilkan Data Barang                              |");
                System.out.println("======================================================================================");
                System.out.println("ID\t\t"+"Nama\t\t"+"Harga\t\t"+"Stock\t\t"+"Jenis"+"\t\t"+"Terjual\t\t\n");
                for (Barang value : tabelBarang) {
                    //System.out.println(value);
                    System.out.println(value.id+"\t\t"+value.nama+"\t\t"+value.harga+"\t\t"+value.stock+"\t\t"+value.jenis+"\t\t"+value.terjual);
                }
                System.out.print("Input id Barang untuk di Remove : ");
                int delet = sc.nextInt();

                for (int j = 0; j < tabelBarang.size(); j++) {
                    if (tabelBarang.get(j).id == delet) {
                        index = j;
                        ditemukan = true;
                    }
                }
                if (ditemukan == true) {
                    tabelBarang.remove(delet);
                    System.out.println("Data ke id->"+delet+" Berhasil dihapus");
                }else if (ditemukan == false) {
                    System.out.println("ID tidak ditemukan");
                }
                
            }//kurung penutup remove barang
            else if (input.equalsIgnoreCase("V")){//kurung pembuka tampilkan barang
                System.out.println("======================================================================================");
                System.out.println("|                                 Tampilkan Data Barang                              |");
                System.out.println("======================================================================================");
                System.out.println("ID\t\t"+"Nama\t\t"+"Harga\t\t"+"Stock\t\t"+"Jenis"+"\t\t"+"Terjual\t\t\n");
                for (Barang value : tabelBarang) {
                    //System.out.println(value);
                    System.out.println(value.id+"\t\t"+value.nama+"\t\t"+value.harga+"\t\t"+value.stock+"\t\t"+value.jenis+"\t\t"+value.terjual);
                }
            }//kurung penutup tampilkan barang
            else if (input.equalsIgnoreCase("P")) {//kurung pembuka penjualan barang
                boolean jualan = true;
                int index = -1;
                while(jualan){
                System.out.println("Anda Memilih Menu PENJUALAN");
                System.out.println("============================================");
                System.out.println("[TP] TAMBAH PENJUALAN");
                System.out.println("[SL] SELESAI");
                System.out.println("============================================\n");
                System.out.print("Menu yang anda pilih : ");
                String jual = sc.nextLine();
                    if (jual.equalsIgnoreCase("TP")) {
                        System.out.println("ID\t\t"+"Nama\t\t"+"Harga\t\t"+"Stock\t\t"+"Jenis"+"\t\t"+"Terjual\t\t\n");
                        for (Barang value : tabelBarang) {
                            //System.out.println(value);
                            System.out.println(value.id+"\t\t"+value.nama+"\t\t"+value.harga+"\t\t"+value.stock+"\t\t"+value.jenis+"\t\t"+value.terjual);
                        }
                        boolean ditemukan = false;
                        System.out.println("\nAnda memilih Menu TAMBAH PENJUALAN");
                        System.out.print("Pilih ID Barang yang  akan dijual:");
                        int dijual= sc.nextInt();
                        System.out.print("Jumlah Barang diJual : ");
                        int laku = sc.nextInt();
                        for (int j = 0; j < tabelBarang.size(); j++) {
                            if (tabelBarang.get(j).id == id) {
                                index = j;
                                ditemukan = true;
                            }
                        }
                        if (ditemukan == true) {
                            
                            Barang updateTerjual = tabelBarang.get(dijual);
                            updateTerjual.stock = tabelBarang.get(dijual).stock-laku;
                            updateTerjual.terjual = tabelBarang.get(dijual).terjual+laku;

                            try{
                                FileWriter fileWriter = new FileWriter(transaksi, true);
                                fileWriter.write("============================================");
                                fileWriter.write("\nData Belanjaan");
                                fileWriter.write("\n-------------------------------");
                                fileWriter.write("\nID Barang     : "+dijual);
                                fileWriter.write("\nNama Barang   : "+tabelBarang.get(index).nama);
                                fileWriter.write("\nJumlah Barang : "+laku);
                                fileWriter.write("\nHarga Barang  : Rp"+tabelBarang.get(index).harga);
                                fileWriter.write("\n-------------------------------");
                                fileWriter.write("\nTotal Bayar   : Rp "+tabelBarang.get(index).harga*laku);
                                fileWriter.write("\n============================================\n");
                                fileWriter.close();
                            }catch(IOException e){
                                System.out.println("Terjadi Kesalahan karena: "+e.getMessage());
                            }
                            try{
                            File myFile = new File(transaksi);
                            Scanner fr = new Scanner(myFile);
                            
                            while(fr.hasNextLine()){
                                String data = fr.nextLine();
                                System.out.println(data);
                            }
                
                            }catch(IOException e){
                                System.out.println("Terjadi Kesalahan karena: "+e.getMessage());
                            }
                        }
                        else if(ditemukan == false){
                            System.out.println("-------------------------------");
                            System.out.println("ID Yang Anda Masukkan Tidak Ditemukan");
                        }
 
                    }else if (jual.equalsIgnoreCase("SL")) {
                        System.out.println("Selesai");

                        System.out.println("total harga");
                        jualan = false;
                    }
                }
                
            }//kurung penutup penjualan barang
            else if (input.equalsIgnoreCase("S")) {//kurung pembuka save barang
                System.out.println("SAVE TO FILE");
                System.out.println("Data Barang Berhasil di Simpan");
                saveTableBarangToFile(tabelBarang, "file_tabel_barang.txt");
                
            }//kurung penutup save barang
            else if (input.equalsIgnoreCase("E")) {//kurung pembuka exit barang
                System.out.println("Anda Memilih Menu EXIT");
                System.out.println("Proses input di akhiri");
                saveTableBarangToFile(tabelBarang, "file_tabel_barang.txt");
                running = false;
            }//kurung penutup exit barang

            else{//kurung pembuka validasi pilihan menu
                System.out.println("Maaf, Menu yang Anda pilih tidak Sesuai");
                System.out.println("Silahkan Pilih Menu dengan Benar");
            }//kurung penutup validasi pilihan menu

        }//kurung penutup while utama
        sc.close();
        
    }

    // Menyimpan file kedalam file text
    public static boolean saveTableBarangToFile (ArrayList<Barang> tabelBarang, String url){
        boolean result = false;
        try{
            if (tabelBarang != null && !tabelBarang.isEmpty() && url != null) {
                FileWriter fw = new FileWriter(url);
                BufferedWriter bw = new BufferedWriter(fw);
                for (Barang b : tabelBarang) {
                    bw.append(b.id+"\t\t"+b.nama+"\t\t"+b.harga+"\t\t"+b.stock+"\t\t"+b.jenis+"\t\t"+b.terjual+"\t\t\n");
                    // bw.append(b.toString());
                    // bw.append("\n");
                }
                bw.close();
                fw.close();
                result = true;
            }
        }catch (IOException e){
            System.out.println("PROSES MENYIMPAN DATA KE FILE GAGAL");
            e.printStackTrace();
        }

        return result;
    }

    // Membaca file dari file text
    public static ArrayList<Barang> readTableBarangFromFile(String url){
        ArrayList<Barang> data = null;
        try {
            FileReader fr =new FileReader(url);
            BufferedReader br = new BufferedReader(fr);
            data = new ArrayList<>();
            String baris;
            while ((baris = br.readLine()) != null) {
                String[] elements = baris.split("\t\t");
                String strId = elements[0];
                int id = Integer.parseInt(strId);
                
                String nama = elements[1];
                
                String strHarga = elements[2];
                double harga = Double.parseDouble(strHarga);
                
                String strStock = elements[3];
                int stock = Integer.parseInt(strStock);

                String jenis = elements[4];

                String strTerjual = elements[5];
                int terjual = Integer.parseInt(strTerjual);

                Barang barang = new Barang(id, nama, harga, stock, jenis, terjual);
                data.add(barang);
            }
            br.close();
            fr.close();
        }catch(IOException e){
            System.err.println("PROSES PEMBACAAN DATA KE FILE GAGAL");
            e.printStackTrace();
        }
        return data;
    }
}
