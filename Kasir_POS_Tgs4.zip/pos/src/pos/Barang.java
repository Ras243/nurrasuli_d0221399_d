package pos;

public class Barang {
    int id;
    String nama;
    double harga;
    int stock;
    String jenis;
    int terjual;

    // constructor
    public Barang(int id, String nama, double harga, int stock, String jenis) {
        this.id = id;
        this.nama = nama;
        this.harga = harga;
        this.stock = stock;
        this.jenis = jenis;
    }
    
    public Barang(int id, String nama, double harga, int stock, String jenis, int terjual) {
        this.id = id;
        this.nama = nama;
        this.harga = harga;
        this.stock = stock;
        this.jenis = jenis;
        this.terjual = terjual;
    }
}








 // public String toString(){
    //     String tampil = "" + id
    //             + ";" + nama
    //             + ";" + harga
    //             + ";" + stock
    //             + ";" + jenis 
    //             + ";" + terjual + "";
    //     return tampil;
                
    // } 